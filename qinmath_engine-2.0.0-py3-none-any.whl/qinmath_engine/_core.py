# Copyright (C) 2025 QinMath Team
# SPDX-License-Identifier: AGPL-3.0-only
# See LICENSE file for full license text.

from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field
from math import isqrt
from decimal import Decimal
import hashlib
import json
import os


_REGISTER_K = 32
_REGISTER_SCALE = 10 ** _REGISTER_K
_OPS_LOG_FLUSH_THRESHOLD = 1000
_DEFAULT_FLUSH_DIR = "./qin_ops_logs"


class RoundingMode(str, Enum):
    DOWN = "down"
    UP = "up"
    TOWARD_ZERO = "toward_zero"
    AWAY_FROM_ZERO = "away_from_zero"
    HALF_UP = "half_up"
    HALF_EVEN = "half_even"


@dataclass(eq=False)
class QinNumber:
    integer_part: int = 0
    decimal_part: int = 0
    register: int = 0
    precision_k: int = 18
    truth_mode: RoundingMode = RoundingMode.HALF_EVEN
    rounding: RoundingMode = RoundingMode.HALF_EVEN
    has_rounding: bool = False
    finalized: bool = False
    ops_count: int = 0

    _scale: int = field(default=0, repr=False)
    _ops_log: list = field(default_factory=list, repr=False)
    _ops_log_fragments: list = field(default_factory=list, repr=False)

    _FROZEN = ('truth_mode', 'precision_k')
    _FROZEN_AFTER_FINALIZE = (
        'integer_part', 'decimal_part', 'register', 'has_rounding', 'finalized',
    )

    def __setattr__(self, name, value):
        d = self.__dict__
        if name in QinNumber._FROZEN and name in d:
            raise AttributeError(f"{name} (R0/K) 不可变")
        if d.get('finalized', False) and name in QinNumber._FROZEN_AFTER_FINALIZE:
            raise AttributeError(f"finalized 后 {name} 不可变")
        object.__setattr__(self, name, value)

    def __post_init__(self):
        if self._scale == 0:
            object.__setattr__(self, '_scale', 10 ** self.precision_k)
        self._normalize_decimal()
        self._update_has_rounding()

    def _normalize_decimal(self):
        scale = self._scale
        if self.decimal_part >= scale:
            carry = self.decimal_part // scale
            object.__setattr__(self, 'decimal_part', self.decimal_part % scale)
            object.__setattr__(self, 'integer_part', self.integer_part + carry)
        elif self.decimal_part < 0:
            borrow = (-self.decimal_part + scale - 1) // scale
            object.__setattr__(self, 'decimal_part', self.decimal_part + borrow * scale)
            object.__setattr__(self, 'integer_part', self.integer_part - borrow)

    def _update_has_rounding(self):
        object.__setattr__(self, 'has_rounding', self.register != 0)

    def _effective_nano(self) -> int:
        base = self.integer_part * self._scale + self.decimal_part
        if self.finalized:
            return base * _REGISTER_SCALE
        return base * _REGISTER_SCALE + self.register

    def _set_from_nano(self, n: int):
        base = n // _REGISTER_SCALE
        reg = n - base * _REGISTER_SCALE
        int_part = base // self._scale
        dec_part = base - int_part * self._scale
        object.__setattr__(self, 'integer_part', int_part)
        object.__setattr__(self, 'decimal_part', dec_part)
        object.__setattr__(self, 'register', reg)

    def copy(self) -> QinNumber:
        new = QinNumber.__new__(QinNumber)
        d = new.__dict__
        d['integer_part'] = self.integer_part
        d['decimal_part'] = self.decimal_part
        d['register'] = self.register
        d['precision_k'] = self.precision_k
        d['truth_mode'] = self.truth_mode
        d['rounding'] = self.rounding
        d['has_rounding'] = self.has_rounding
        d['finalized'] = self.finalized
        d['ops_count'] = self.ops_count
        d['_scale'] = self._scale
        d['_ops_log'] = list(self._ops_log)
        d['_ops_log_fragments'] = list(self._ops_log_fragments)
        return new

    def _prepare_for_op(self, rm: RoundingMode) -> QinNumber:
        result = self.copy()
        if result.finalized:
            object.__setattr__(result, 'finalized', False)
            object.__setattr__(result, 'ops_count', 0)
            object.__setattr__(result, 'register', 0)
            object.__setattr__(result, 'has_rounding', False)
            object.__setattr__(result, '_ops_log', [])
        object.__setattr__(result, 'rounding', rm)
        return result

    def add(self, other: QinNumber) -> QinNumber:
        result = self._prepare_for_op(self.rounding)
        n = self._effective_nano() + other._effective_nano()
        result._set_from_nano(n)
        result._update_has_rounding()
        object.__setattr__(result, 'ops_count', result.ops_count + 1)
        result._ops_log.append({
            'op': 'add', 'a': str(self), 'b': str(other), 'result': str(result),
        })
        result._flush_if_needed()
        return result

    def sub(self, other: QinNumber) -> QinNumber:
        return self.add(other.negate())

    def negate(self) -> QinNumber:
        scale = self._scale
        P = -(self.integer_part * scale * _REGISTER_SCALE
              + self.decimal_part * _REGISTER_SCALE
              + self.register)
        new_int = P // (scale * _REGISTER_SCALE)
        rem = P - new_int * scale * _REGISTER_SCALE
        new_dec = rem // _REGISTER_SCALE
        new_reg = rem % _REGISTER_SCALE
        new = self.copy()
        object.__setattr__(new, 'integer_part', new_int)
        object.__setattr__(new, 'decimal_part', new_dec)
        object.__setattr__(new, 'register', new_reg)
        new._update_has_rounding()
        return new

    def multiply(self, other: QinNumber,
                 rounding: RoundingMode | None = None) -> QinNumber:
        rm = rounding if rounding is not None else self.rounding
        result = self._prepare_for_op(rm)

        NS = self._scale * _REGISTER_SCALE
        n = (self._effective_nano() * other._effective_nano()) // NS
        result._set_from_nano(n)
        result._update_has_rounding()

        object.__setattr__(result, 'ops_count', result.ops_count + 1)
        result._ops_log.append({
            'op': 'multiply', 'rounding': rm.value,
            'a': str(self), 'b': str(other), 'result': str(result),
        })
        result._flush_if_needed()
        return result

    def divide(self, other: QinNumber,
               rounding: RoundingMode | None = None) -> QinNumber:
        rm = rounding if rounding is not None else self.rounding
        result = self._prepare_for_op(rm)

        NS = self._scale * _REGISTER_SCALE
        na = self._effective_nano()
        nb = other._effective_nano()
        if nb == 0:
            raise ZeroDivisionError("division by zero")
        n = (na * NS) // nb
        result._set_from_nano(n)
        result._update_has_rounding()

        object.__setattr__(result, 'ops_count', result.ops_count + 1)
        result._ops_log.append({
            'op': 'divide', 'rounding': rm.value,
            'a': str(self), 'b': str(other), 'result': str(result),
        })
        result._flush_if_needed()
        return result

    def sqrt(self, rounding: RoundingMode | None = None) -> QinNumber:
        rm = rounding if rounding is not None else self.rounding
        result = self._prepare_for_op(rm)

        NS = self._scale * _REGISTER_SCALE
        na = self._effective_nano()
        if na < 0:
            raise ValueError("sqrt of negative number")

        n = isqrt(na * NS)
        result._set_from_nano(n)
        result._update_has_rounding()

        object.__setattr__(result, 'ops_count', result.ops_count + 1)
        result._ops_log.append({
            'op': 'sqrt', 'rounding': rm.value,
            'a': str(self), 'result': str(result),
        })
        result._flush_if_needed()
        return result

    def finalize(self) -> QinNumber:
        if self.finalized:
            return self.copy()

        result = self.copy()
        rm = result.rounding

        if result.register != 0:
            reg = result.register
            base = result.integer_part * result._scale + result.decimal_part
            x_neg = base < 0
            twice = reg * 2
            inc = 0

            if rm is RoundingMode.DOWN:
                inc = 0
            elif rm is RoundingMode.UP:
                inc = 1 if reg > 0 else 0
            elif rm is RoundingMode.TOWARD_ZERO:
                inc = 1 if (x_neg and reg > 0) else 0
            elif rm is RoundingMode.AWAY_FROM_ZERO:
                inc = 1 if ((not x_neg) and reg > 0) else 0
            elif rm is RoundingMode.HALF_UP:
                if twice > _REGISTER_SCALE:
                    inc = 1
                elif twice < _REGISTER_SCALE:
                    inc = 0
                else:
                    inc = 1 if not x_neg else 0
            elif rm is RoundingMode.HALF_EVEN:
                if twice > _REGISTER_SCALE:
                    inc = 1
                elif twice < _REGISTER_SCALE:
                    inc = 0
                else:
                    inc = 1 if (base % 2 != 0) else 0

            object.__setattr__(result, 'register', reg - inc * _REGISTER_SCALE)
            if inc:
                object.__setattr__(result, 'decimal_part',
                                   result.decimal_part + 1)
                result._normalize_decimal()

        result._update_has_rounding()
        object.__setattr__(result, 'finalized', True)
        return result

    def _compare_key(self) -> int:
        return (self.integer_part * self._scale + self.decimal_part) \
               * _REGISTER_SCALE + self.register

    def _check_comparable(self, other):
        if not isinstance(other, QinNumber):
            return NotImplemented
        if self.precision_k != other.precision_k:
            raise ValueError("K 值不同的 QinNumber 不能比较 (维度不同)")
        return True

    def __eq__(self, other):
        if self._check_comparable(other) is NotImplemented:
            return NotImplemented
        return self._compare_key() == other._compare_key()

    def __ne__(self, other):
        eq = self.__eq__(other)
        return eq if eq is NotImplemented else not eq

    def __lt__(self, other):
        if self._check_comparable(other) is NotImplemented:
            return NotImplemented
        return self._compare_key() < other._compare_key()

    def __le__(self, other):
        if self._check_comparable(other) is NotImplemented:
            return NotImplemented
        return self._compare_key() <= other._compare_key()

    def __ge__(self, other):
        if self._check_comparable(other) is NotImplemented:
            return NotImplemented
        return self._compare_key() >= other._compare_key()

    def __gt__(self, other):
        if self._check_comparable(other) is NotImplemented:
            return NotImplemented
        return self._compare_key() > other._compare_key()

    def __hash__(self):
        return hash(self._compare_key())

    def __str__(self) -> str:
        total = self.integer_part * self._scale + self.decimal_part
        sign = '-' if total < 0 else ''
        mag = -total if total < 0 else total
        body = f"{sign}{mag // self._scale}." \
               f"{str(mag % self._scale).zfill(self.precision_k)}"
        return ('!' if self.register != 0 else '') + body

    def __repr__(self) -> str:
        total = self.integer_part * self._scale + self.decimal_part
        sign = '-' if total < 0 else ''
        mag = -total if total < 0 else total
        body = f"{sign}{mag // self._scale}." \
               f"{str(mag % self._scale).zfill(self.precision_k)}"
        return (f"Q({body} | reg={self.register} "
                f"R0={self.truth_mode.value} R1={self.rounding.value})")

    @property
    def value(self) -> float:
        return self.integer_part + self.decimal_part / self._scale

    def to_decimal(self) -> Decimal:
        scale = Decimal(10) ** self.precision_k
        d = Decimal(self.integer_part) + Decimal(self.decimal_part) / scale
        if self.register:
            d += Decimal(self.register) / (scale * _REGISTER_SCALE)
        return d

    def to_canonical_json(self) -> str:
        data = {
            "integer_part": str(self.integer_part),
            "decimal_part": str(self.decimal_part).zfill(self.precision_k),
            "precision_k": self.precision_k,
            "register_k": _REGISTER_K,
            "truth_mode": self.truth_mode.value,
            "rounding_used": self.rounding.value,
            "has_rounding": self.has_rounding,
            "register": str(self.register),
            "ops_count": self.ops_count,
            "finalized": self.finalized,
            "ops_log": self._ops_log[-10:] if self._ops_log else [],
            "ops_log_fragments": list(self._ops_log_fragments),
        }
        return json.dumps(data, sort_keys=True, ensure_ascii=False)

    def evidence_hash(self) -> str:
        return hashlib.sha256(
            self.to_canonical_json().encode("utf-8")).hexdigest()

    def verify(self, expected_hash: str) -> bool:
        return self.evidence_hash() == expected_hash

    def _flush_if_needed(self):
        if len(self._ops_log) >= _OPS_LOG_FLUSH_THRESHOLD:
            self._flush_ops_log()

    def _flush_ops_log(self, out_dir: str | None = None):
        if not self._ops_log:
            return
        out_dir = out_dir or _DEFAULT_FLUSH_DIR
        os.makedirs(out_dir, exist_ok=True)
        anchor = self.evidence_hash()[:8]
        index = len(self._ops_log_fragments)
        payload = {
            "chain_anchor": anchor,
            "fragment_index": index,
            "ops_count_at_flush": self.ops_count,
            "entries": self._ops_log,
        }
        path = os.path.join(
            out_dir, f"qin_ops_log_{anchor}_{index:03d}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, sort_keys=True)
        object.__setattr__(self, '_ops_log_fragments',
                           self._ops_log_fragments + [path])
        object.__setattr__(self, '_ops_log', [])

    @classmethod
    def from_int(cls, value: int, k: int = 18,
                 truth_mode: RoundingMode = RoundingMode.HALF_EVEN,
                 rounding: RoundingMode = RoundingMode.HALF_EVEN,
                 ) -> "QinNumber":
        return cls(integer_part=int(value), decimal_part=0, register=0,
                   precision_k=k, truth_mode=truth_mode, rounding=rounding)

    @classmethod
    def from_string(cls, s: str, k: int = 18,
                    truth_mode: RoundingMode = RoundingMode.HALF_EVEN,
                    rounding: RoundingMode = RoundingMode.HALF_EVEN,
                    ) -> "QinNumber":
        text = str(s).strip()
        if not text:
            raise ValueError("empty string")
        sign = 1
        if text[0] in '+-':
            if text[0] == '-':
                sign = -1
            text = text[1:]
        if '.' in text:
            int_s, frac_s = text.split('.', 1)
        else:
            int_s, frac_s = text, ''
        if not int_s:
            int_s = '0'
        if not int_s.isdigit() or (frac_s and not frac_s.isdigit()):
            raise ValueError(f"非法数字字符串: {s!r}")
        mag_int = int(int_s)
        frac_pad = (frac_s[:k] if k > 0 else '').ljust(k, '0')
        mag_dec = int(frac_pad) if k > 0 else 0
        extra = frac_s[k:] if k > 0 else frac_s
        if extra:
            if len(extra) <= _REGISTER_K:
                mag_reg = int(extra) * (10 ** (_REGISTER_K - len(extra)))
            else:
                mag_reg = int(extra[:_REGISTER_K])
        else:
            mag_reg = 0
        q = cls(integer_part=mag_int, decimal_part=mag_dec, register=mag_reg,
                precision_k=k, truth_mode=truth_mode, rounding=rounding)
        if sign < 0:
            q = q.negate()
        return q

    @classmethod
    def from_float(cls, val: float, k: int = 18,
                   truth_mode: RoundingMode = RoundingMode.HALF_EVEN,
                   rounding: RoundingMode = RoundingMode.HALF_EVEN,
                   ) -> "QinNumber":
        return cls.from_string(str(val), k, truth_mode, rounding)

    @classmethod
    def from_decimal(cls, val: Decimal, k: int = 18,
                     truth_mode: RoundingMode = RoundingMode.HALF_EVEN,
                     rounding: RoundingMode = RoundingMode.HALF_EVEN,
                     ) -> "QinNumber":
        return cls.from_string(val.to_eng_string(), k, truth_mode, rounding)


def qin_sum(values: list[QinNumber]) -> QinNumber:
    if not values:
        return QinNumber()
    result = values[0]
    for v in values[1:]:
        result = result.add(v)
    return result


def qin_chain_multiply(values: list[QinNumber],
                       rounding: RoundingMode | None = None) -> QinNumber:
    if not values:
        return QinNumber()
    result = values[0]
    for v in values[1:]:
        result = result.multiply(v, rounding)
    return result


def qin_chain_divide(values: list[QinNumber],
                     rounding: RoundingMode | None = None) -> QinNumber:
    if not values:
        return QinNumber()
    result = values[0]
    for v in values[1:]:
        result = result.divide(v, rounding)
    return result


__all__ = ['RoundingMode', 'QinNumber', 'qin_sum', 'qin_chain_multiply',
           'qin_chain_divide']
