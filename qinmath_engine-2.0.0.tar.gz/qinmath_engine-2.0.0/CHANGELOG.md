# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] - 2025-10-27

### Added
- Separation-storage fixed-point engine: unbounded integer_part + K-digit decimal_part + 32-bit register shadow
- Full-grid integer arithmetic for add / sub / multiply / divide / sqrt
- Six rounding modes: DOWN, UP, TOWARD_ZERO, AWAY_FROM_ZERO, HALF_UP, HALF_EVEN
- Dual-mode rounding system: R0 truth_mode (frozen) + R1 rounding (mutable per finalize)
- Construction helpers: from_int, from_string, from_float, from_decimal
- Evidence chain: canonical JSON + SHA-256 hash + ops_log auto-flush
- Convenience functions: qin_sum, qin_chain_multiply, qin_chain_divide
- Full comparison protocol: __eq__, __ne__, __lt__, __le__, __ge__, __gt__, __hash__
- AGPL-3.0-only license + CLA (individual & entity)

### Changed
- Rewrite from pre-release prototype (qinmath_core.py, truncated at __le__) to complete qinmath_engine package
